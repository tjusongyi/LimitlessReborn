﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Windows.Storage.Streams;
using System.Runtime.InteropServices.WindowsRuntime;

namespace SocketEx
{
    public sealed class DataReaderWriterStream : System.IO.Stream
    {
        private TcpClient Client { get; set; }
        private DataReader Reader { get; set; }
        private DataWriter Writer { get; set; }

        public DataReaderWriterStream(TcpClient client)
        {
            this.Client = client;
            this.Reader = new DataReader(Client.Socket.InputStream);
            this.Writer = new DataWriter(Client.Socket.OutputStream);
        }

        #region Stream interface

        public override bool CanRead
        {
            get { return true; }
        }

        public override bool CanSeek
        {
            get { return false; }
        }

        public override bool CanWrite
        {
            get { return true; }
        }

        public override void Flush()
        {
            Writer.StoreAsync().AsTask().Wait();
        }

        public override long Length
        {
            get { throw new NotImplementedException(); }
        }

        public override long Position
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public bool DataAvailable
        {
            get
            {
                return Reader.UnconsumedBufferLength > 0;
            }
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            Windows.Storage.Streams.Buffer tmpBuffer = new Windows.Storage.Streams.Buffer((uint)count);
            var task = Client.Socket.InputStream.ReadAsync(tmpBuffer, (uint)count, InputStreamOptions.None);

            if (!task.AsTask().Wait(Client.ReadTimeout))
                throw new TimeoutException("Read timed out!");

            DataReader buf = DataReader.FromBuffer(tmpBuffer);
            int length = (int)buf.UnconsumedBufferLength;
            for (int i = 0; i < length; ++i)
                buffer[offset + i] = buf.ReadByte();
            return length;
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            for (int i = 0; i < count; ++i)
                Writer.WriteByte(buffer[offset + i]);
        }

        public override long Seek(long offset, System.IO.SeekOrigin origin)
        {
            throw new NotImplementedException();
        }

        public override void SetLength(long value)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Dispose

        private bool disposed = false;
        protected override void Dispose(bool disposing)
        {
            if (!disposed)
            {
                disposed = true;

                if (disposing)
                {
                    if (Reader != null)
                    {
                        Reader.Dispose();
                        Reader = null;
                    }

                    if (Writer != null)
                    {
                        Writer.Dispose();
                        Writer = null;
                    }

                    if (Client != null)
                        Client.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #endregion
    }
}*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage.Streams;

namespace SocketEx
{
    public sealed class DataReaderWriterStream : System.IO.Stream
    {
        private TcpClient Client { get; set; }
        private DataReader Reader { get; set; }
        private DataWriter Writer { get; set; }

        public DataReaderWriterStream(TcpClient socket)
        {
            this.Client = socket;
            this.Reader = new DataReader(Client.Socket.InputStream);
            this.Writer = new DataWriter(Client.Socket.OutputStream);
        }

        #region Stream interface

        public override bool CanRead
        {
            get { return true; }
        }

        public override bool CanSeek
        {
            get { return false; }
        }

        public override bool CanWrite
        {
            get { return true; }
        }

        public override void Flush()
        {
            Writer.StoreAsync().AsTask().Wait();
        }

        public override long Length
        {
            get { throw new NotImplementedException(); }
        }

        public override long Position
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public bool DataAvailable
        {
            get
            {
                return Reader.UnconsumedBufferLength > 0;
            }
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            Windows.Storage.Streams.Buffer tmpBuffer = new Windows.Storage.Streams.Buffer((uint)count);
            var task = Client.Socket.InputStream.ReadAsync(tmpBuffer, (uint)count, InputStreamOptions.None);
            task.AsTask().Wait();

            DataReader buf = DataReader.FromBuffer(tmpBuffer);
            int length = (int)buf.UnconsumedBufferLength;
            for (int i = 0; i < length; ++i)
                buffer[offset + i] = buf.ReadByte();
            return length;

            /*for (int i = 0; i < count; ++i)
                buffer[offset + i] = Reader.ReadByte();

            return count;*/
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            for (int i = 0; i < count; ++i)
                Writer.WriteByte(buffer[offset + i]);
        }

        public override long Seek(long offset, System.IO.SeekOrigin origin)
        {
            throw new NotImplementedException();
        }

        public override void SetLength(long value)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Dispose

        private bool disposed = false;
        protected override void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    if (Reader != null)
                    {
                        Reader.Dispose();
                        Reader = null;
                    }

                    if (Writer != null)
                    {
                        Writer.Dispose();
                        Writer = null;
                    }
                }
                disposed = true;
            }
            base.Dispose(disposing);
        }

        #endregion
    }
}